import csv
from random import seed
from random import randint

strat_list = []

questions = [
    'Is it a general phrase (widely applicable)?',
    '',
    'Does the card concern action?',
    'Does the card concern artifact?',
    'Does the card concern actor?',
    'Does the card concern audenciece?',
    'Does the card concern affordances?',
    '',
    'Can the card concern the preparation stage?',
    'Can the card concern the incubation stage?',
    'Can the card concern the intimation stage?',
    'Can the card concern the illumination stage?',
    'Can the card concern the verification stage?',
    '',
    'Is the phrase a call to action?',
    'Is the phrase a general statement?',
    'Is the phrase a question?',
    '',
    'Is the idea presented concrete (not abstract)?'
]

with open('cards.csv', newline='') as csvfile:
    reader = csv.reader(csvfile, delimiter='$', quotechar='|')
    count_lines = 0
    for row in reader:
        #print(row)
        strat_list.append(row[0])
        count_lines += 1


    intro_text ="""
    Hello,

    This is a survey to understand how the Oblique Strategies cards by Brian Eno
    can be characterized. Using this test an agreement matrix can be created
    based on answers submitted by multiple users to find a common ground of
    how the cards are perceived. The questions revolve around the creative
    domain, type of process and subject aspects of the cards.

    10 cards will be presented to you each with the same set of 15 questions.
    The questions are all yes or no questions that you can answer with 'yes' / 'y'
    or 'no' / 'n'. If you take 2 minutes or less to answer the questions for
    each card the survey will take < 20 min.

    Please read the explanation below carefully.

    The first question is on the generality of the card. The question
    is whether the cards is applicable (interpretable) in a large set of
    creative domains or only in one domain/setting/discipline.

    A set of 5 questions are presented afterwards where you can decide if the
    card has to do with an Actor (personal attributes in relation to a societal
    context), Action (coordinated psychological and behavioral manifestation),
    Artifact (cultural context of artifact production and evaluation),
    Audience (the interdependence between creators and the social world) and
    Affordances (the interdependence between creators and the material word)

    Then another set of 5 questions are presented where you can choose multiple
    stages that the card could be attached to, namely Wallas’ creative process
    stages:Preparation, incubation, intimation, illumination and verification.

    The Preparation and Verification stages are conscious “voluntary”
    and “regulated” rather than a “wild ranging of the mind”.
    logic, mathematics, experiments and observations are tytpical aspects
    Preparation and Verification. Preparation concerns also gathering information
    strategies while Verification is a way to evuluate the work.

    Incubation can have one of two attributes. The first is that
    “we do not voluntarily or consciously think on a particular problem”.
    The second attribute is that
    “a series of unconscious and involuntary (or foreconscious/forevoluntary)
    mental events may take place”.
    As for the first attribute, abstention from mental work may take one
    of two forms, “conscious mental work on other problems” (distraction)
    and “relaxation from all mental work” (mental relaxation).

    Intimation is a semi consious process where the train of conscious arises
    naturally with little interference in this process before the idea is as
    well-formed as possible and then it's about capturing the essence
    of this process before it has drifted away. Illumination is more of
    a singular moment where the 'click' happens and everything comes together
    to present the solution.

    Then 3 questions are presented where you can decide if the given phrase
    is a call to action, question or a statement.

    The last question is posed is whether the idea presented on the card
    is a concrete one, meaning that it's specific in your opinion and
    not abstract.

    If you are confused by any of the cards or questions answer to your best
    judgement or best guess.

    """
    print(intro_text)

    outro_text = """\n\n
    Thank you for participating!

    Please mail the produced output.csv file to wahagnm@gmail.com
    as an attachment and as the title of the mail input 'Oblique Questionnaire'.

    If you have any remarks about the questions, your answers or have any
    other thoughts (for example on potential improvements or articles to look into)
    feel free to add it to the body of the mail.

    """

    seed(1)

    f = open("output.csv", "w")

    cardcount = 0
    for _ in range(10):
        cardcount += 1
        print('\n\n************* [CARD', cardcount, '/ 10 ] *************')
        value = randint(0, count_lines-1) #skip last line line in csv
        print('\nPlease characterize the following phrase:')
        print('\n\t', strat_list[value], '\n')


        out_line =  strat_list[value]
        for q in questions:
            print(q)
            answer = ''
            if q == '':
                print('***** \n\n')
                out_line += '$'
            else:
                while answer == '':
                    user_answer = input ("Type yes or no: ")
                    if user_answer == 'y' or user_answer == 'yes':
                        answer = 'yes'
                    if user_answer == 'n' or user_answer == 'no':
                        answer = 'no'
                out_line += '$' + answer

        out_line += '\n'
        f.write(out_line)

    f.close()

    print(outro_text)
